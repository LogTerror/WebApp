<!DOCTYPE html>
<html>
<head>
	<title>Grade Store</title>
	<link href="gradestore.css" type="text/css" rel="stylesheet" />
</head>
<body>
    <?php
    $name = $_POST["name"];
    $id = $_POST["id"];
    $names = ["cse326", "cse107", "cse603", "cin870"];
    $grade = $_POST["grade"];
	$creditNum = $_POST["creditNum"];
	$cc = $_POST["cc"];
	if (!strcmp($name, "") || !strcmp($id, "") || !strcmp($creditNum, "")) {
	?>
		<h1>Sorry</h1>
		<p>You didn't fill out the form completely. Try again?</p>
	<?php
	} elseif (!preg_match("/^[a-z][a-z -]*$/i", $name)) { 
	?>
		Display the below error message : 
		<h1>Sorry</h1>
		<p>You didn't provide a valid name. Try again?</p>
	<?php
	} elseif (!preg_match_all("/\d{16}/", $creditNum) || !(($cc=="Visa" && $creditNum[0]=="4") | ($cc=="MasterCard" && $creditNum[0]=="5"))) {
	?>
		Display the below error message : 
		<h1>Sorry</h1>
		<p>You didn't provide a valid credit card number. Try again?</p>
	<?php 
	} else {
	?>
	<h1>Thanks, looser!</h1>
	<p>Your information has been recorded.</p>
	<ul> 
		<li>Name: <?=$name?></li>
		<li>ID: <?=$id?></li>
        <li>Course: <?=processCheckbox($names)?></li>
		<li>Grade: <?=$grade?></li>
		<li>Credit <?=$creditNum?>(<?=$cc?>)</li>
	</ul>
		<p>Here are all the loosers who have submitted here:</p>
	<?php
		$filename = "loosers.txt";
			 file_put_contents("loosers.txt", $name.";".$id.";".$creditNum.";".$cc."\n", FILE_APPEND); 
	?>
	<?php
		$lines = file($filename);		
		foreach ($lines as $key) { ?>
				<p><?=$key?></p>
	<?php }
	}
	function processCheckbox($names){
		$result = "";
		foreach ($names as $key) {
				$check = $_POST[$key];
				if(isset($check)) {
					if($result=="") {
						$result = $check;
	}
                    else {
						$result = $result.", ".$check;
					}
				}
			}
			return $result;
		}
		?>
</body>
</html>